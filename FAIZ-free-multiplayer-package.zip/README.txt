# FAIZ Kerala Open World — Multiplayer

This package adds a Socket.IO server to the supplied `faiz.html` game.

## Run on a computer
1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000` in a browser.

## Put it online
Deploy this folder as a Node.js web service on a host that supports persistent WebSocket connections.
Use:
- Build command: `npm install`
- Start command: `npm start`

Open the HTTPS URL given by the host. The game uses the same host for Socket.IO.
For two phones to meet online, both must open that same deployed HTTPS URL.

## Notes
- Public room code: `MAIN` (the in-game “FAIZ public server” button).
- Private rooms are created from the multiplayer panel if those controls are shown in the game.
- The free hosting provider may sleep or impose limits; free hosting is not guaranteed to be always online.
- Voice chat requires HTTPS and microphone permission. Browser/device support varies.
