const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" },
  pingInterval: 25000,
  pingTimeout: 20000,
  maxHttpBufferSize: 1e6
});

app.use(express.static(__dirname));
app.get("/health", (_req, res) => res.json({ ok: true, service: "FAIZ Multiplayer" }));

const rooms = new Map();
const clean = (v, n=24) => String(v ?? "").replace(/[<>]/g, "").trim().slice(0,n);
const makeCode = () => Math.random().toString(36).slice(2,7).toUpperCase();

function roster(room) {
  return [...room.players.values()].map(p => ({
    id: p.id, name: p.name, host: p.id === room.host, vc: !!p.vc
  }));
}
function sendRoster(room) {
  io.to(room.code).emit("roster", roster(room));
  io.to(room.code).emit("hostid", room.host);
}
function snapshots(room) {
  return [...room.players.values()].map(p => ({
    id:p.id, x:p.x, z:p.z, h:p.h, v:p.v, hid:p.hid
  }));
}
function removeFromRoom(socket) {
  const code = socket.data.room;
  if (!code) return;
  const room = rooms.get(code);
  socket.leave(code);
  socket.data.room = null;
  if (!room) return;
  room.players.delete(socket.id);
  if (!room.players.size) {
    rooms.delete(code);
    return;
  }
  if (room.host === socket.id) room.host = room.players.keys().next().value;
  sendRoster(room);
}

function joinRoom(socket, payload={}) {
  const code = clean(payload.code, 12).toUpperCase();
  const name = clean(payload.name || socket.data.name || "Player", 14) || "Player";
  const room = rooms.get(code);
  if (!room) return socket.emit("err", "മുറി കണ്ടെത്തിയില്ല");
  if (room.players.has(socket.id)) return;
  if (room.players.size >= room.max) return socket.emit("err", "മുറി നിറഞ്ഞു");
  removeFromRoom(socket);
  const p = { id:socket.id, name, x:8, z:0, h:0, v:-1, hid:0, vc:0 };
  room.players.set(socket.id,p);
  socket.data.room = code;
  socket.data.name = name;
  socket.join(code);
  socket.emit("joined", {
    code, rn:room.name, max:room.max, host:room.host,
    players:roster(room)
  });
  sendRoster(room);
}

io.on("connection", socket => {
  socket.data.room = null;
  socket.on("reg", name => { socket.data.name = clean(name,14) || "Player"; });

  socket.on("create", data => {
    removeFromRoom(socket);
    let code = clean(data?.code,12).toUpperCase() || makeCode();
    if (rooms.has(code)) return socket.emit("err", "ഈ മുറി നമ്പർ ഇതിനകം ഉപയോഗത്തിലാണ്");
    const max = Math.max(2, Math.min(12, Number(data?.max) || 8));
    const room = { code, name:clean(data?.rn,30) || "FAIZ Room", max, host:socket.id, players:new Map(), world:null };
    rooms.set(code, room);
    joinRoom(socket, { code, name:data?.name });
  });

  socket.on("join", data => joinRoom(socket, data));

  socket.on("p", data => {
    const room = rooms.get(socket.data.room);
    const p = room?.players.get(socket.id);
    if (!p || !data || typeof data !== "object") return;
    p.x = Number.isFinite(+data.x) ? Math.max(-500,Math.min(500,+data.x)) : p.x;
    p.z = Number.isFinite(+data.z) ? Math.max(-3000,Math.min(3000,+data.z)) : p.z;
    p.h = Number.isFinite(+data.h) ? +data.h : p.h;
    p.v = Number.isInteger(+data.v) ? +data.v : -1;
    p.hid = data.hid ? 1 : 0;
    socket.to(room.code).volatile.emit("s", snapshots(room));
  });

  socket.on("w", world => {
    const room = rooms.get(socket.data.room);
    if (!room || room.host !== socket.id || !world || typeof world !== "object") return;
    room.world = world;
    socket.to(room.code).volatile.emit("w", world);
  });

  socket.on("chat", message => {
    const room = rooms.get(socket.data.room);
    const p = room?.players.get(socket.id);
    const t = clean(message,180);
    if (room && p && t) io.to(room.code).emit("chat", { n:p.name, t });
  });

  socket.on("pg", cb => { if (typeof cb === "function") cb(); });

  socket.on("vc", value => {
    const room = rooms.get(socket.data.room);
    const p = room?.players.get(socket.id);
    if (!p) return;
    p.vc = value ? 1 : 0;
    sendRoster(room);
  });

  socket.on("sig", msg => {
    const room = rooms.get(socket.data.room);
    if (!room || !msg || typeof msg.to !== "string" || !room.players.has(msg.to)) return;
    io.to(msg.to).emit("sig", { from:socket.id, data:msg.data });
  });

  socket.on("presence", (friends, cb) => {
    const online = [];
    if (Array.isArray(friends)) {
      for (const room of rooms.values()) {
        for (const p of room.players.values()) {
          if (friends.some(n => String(n).toLowerCase() === p.name.toLowerCase())) online.push(p.name.toLowerCase());
        }
      }
    }
    if (typeof cb === "function") cb([...new Set(online)]);
  });

  socket.on("invite", msg => {
    const room = rooms.get(socket.data.room);
    const from = room?.players.get(socket.id);
    if (!room || !from || !msg) return;
    const target = clean(msg.to,14).toLowerCase();
    for (const [id, other] of room.players) {
      if (id !== socket.id && other.name.toLowerCase() === target) {
        io.to(id).emit("invited", { from:from.name, code:room.code });
      }
    }
  });

  socket.on("leave", () => removeFromRoom(socket));
  socket.on("disconnect", () => removeFromRoom(socket));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, "0.0.0.0", () => console.log(`FAIZ Multiplayer running on ${PORT}`));
